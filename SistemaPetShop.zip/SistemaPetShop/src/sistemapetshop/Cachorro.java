package sistemapetshop;

/**
 *
 * @author joao_vl_machado
 */
public class Cachorro extends Animal {
    String dono;

    public Cachorro(String dono, String nome, String peso, String idade, String raca) {
        super(nome, peso, idade, raca);
        this.dono = dono;
    }

    public String getDono() {
        return dono;
    }

    public void setDono(String dono) {
        this.dono = dono;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPeso() {
        return peso;
    }

    public void setPeso(String peso) {
        this.peso = peso;
    }

    public String getIdade() {
        return idade;
    }

    public void setIdade(String idade) {
        this.idade = idade;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }
}

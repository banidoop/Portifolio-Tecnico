package sistemapetshop;

/**
 *
 * @author joao_vl_machado
 */
public class Animal {
    String nome;
    String peso;
    String idade;
    String raca;

    public Animal(String nome, String peso, String idade, String raca) {
        this.nome = nome;
        this.peso = peso;
        this.idade = idade;
        this.raca = raca;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPeso() {
        return peso;
    }

    public void setPeso(String peso) {
        this.peso = peso;
    }

    public String getIdade() {
        return idade;
    }

    public void setIdade(String idade) {
        this.idade = idade;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }
    
}

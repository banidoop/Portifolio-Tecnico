package com.example.Joao;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdaptadorLista extends RecyclerView.Adapter<AdaptadorLista.MyViewHolder> {
    Context context;
    ArrayList<Produto> lista;
    AdaptadorLista.onItemClickListner listner;

    public AdaptadorLista(Context context, ArrayList<Produto> lista, onItemClickListner listner) {
        this.context = context;
        this.lista = lista;
        this.listner = listner;
    }

    @NonNull
    @Override
    public AdaptadorLista.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.layout, parent, false);
        return new AdaptadorLista.MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull AdaptadorLista.MyViewHolder holder, int position) {
        Produto p = lista.get(position);
        holder.nome.setText(p.nome);
        holder.preco.setText(p.preco);
        holder.itemView.setOnClickListener(View ->{
            listner.onItemClick(p);
        });
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }



    public interface onItemClickListner {
        void onItemClick(Produto produto);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView nome,preco;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            nome = itemView.findViewById(R.id.nomeCard);
            preco = itemView.findViewById(R.id.precoCard);
        }
    }
}

package com.example.Joao;

public class Produto {
    String nome;
    String preco;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPreco() {
        return preco;
    }

    public void setPreco(String preco) {
        this.preco = preco;
    }

    public Produto() {
    }

    public Produto(String nome, String preco) {
        this.nome = nome;
        this.preco = preco;
    }
}
